"use server";

import { z } from "zod";
import { revalidatePath } from "next/cache";
import { prisma } from "@/lib/prisma";
import { requireRole, requireCourseManager, requireUser } from "@/lib/access";
import { slugify } from "@/lib/utils";
import { savePublicImage, assertValidPoster } from "@/lib/storage";
import type { ActionResult } from "@/lib/actions/auth-actions";

const courseSchema = z.object({
  title: z.string().trim().min(3).max(160),
  titleEn: z.string().trim().max(160).optional().or(z.literal("")),
  subtitle: z.string().trim().max(200).optional().or(z.literal("")),
  subtitleEn: z.string().trim().max(200).optional().or(z.literal("")),
  description: z.string().trim().max(4000).optional().or(z.literal("")),
  descriptionEn: z.string().trim().max(4000).optional().or(z.literal("")),
  price: z.coerce.number().min(0).max(1_000_000).transform((v) => Math.round(v)),
  level: z.enum(["BEGINNER", "INTERMEDIATE", "ADVANCED"]),
  categoryId: z.string().trim().optional().or(z.literal("")),
  trainerId: z.string().trim().min(1),
  introVideoUrl: z.string().trim().max(500).optional().or(z.literal("")),
});

function parseOptionalHours(formData: FormData): number | null {
  const raw = String(formData.get("totalHours") ?? "").trim();
  if (!raw) return null;
  const n = Number(raw);
  return Number.isFinite(n) && n >= 0 ? n : null;
}

async function uniqueSlug(base: string): Promise<string> {
  const root = slugify(base) || "course";
  let slug = root;
  let i = 1;
  while (await prisma.course.findUnique({ where: { slug } })) {
    slug = `${root}-${++i}`;
  }
  return slug;
}

export async function createCourse(formData: FormData): Promise<ActionResult> {
  try {
    const user = await requireRole(["ADMIN", "TRAINER"]);
    const parsed = courseSchema.safeParse({
      title: formData.get("title"),
      titleEn: formData.get("titleEn"),
      subtitle: formData.get("subtitle"),
      subtitleEn: formData.get("subtitleEn"),
      description: formData.get("description"),
      descriptionEn: formData.get("descriptionEn"),
      price: formData.get("price") || 0,
      level: formData.get("level") || "BEGINNER",
      categoryId: formData.get("categoryId"),
      trainerId: formData.get("trainerId") || user.id,
      introVideoUrl: formData.get("introVideoUrl"),
    });
    if (!parsed.success) {
      return { ok: false, error: parsed.error.issues[0]?.message ?? "بيانات غير صحيحة" };
    }
    const data = parsed.data;
    // Trainers can only create courses under their own name; only admins may assign a different trainer.
    if (user.role === "TRAINER") data.trainerId = user.id;
    const slug = await uniqueSlug(data.title);

    let posterUrl: string | undefined;
    const poster = formData.get("poster");
    if (poster instanceof File && poster.size > 0) {
      assertValidPoster(poster);
      posterUrl = await savePublicImage(poster, "posters");
    }

    await prisma.course.create({
      data: {
        slug,
        title: data.title,
        titleEn: data.titleEn || null,
        subtitle: data.subtitle || null,
        subtitleEn: data.subtitleEn || null,
        description: data.description || null,
        descriptionEn: data.descriptionEn || null,
        price: data.price,
        totalHours: user.role === "ADMIN" ? parseOptionalHours(formData) : null,
        level: data.level,
        categoryId: data.categoryId || null,
        trainerId: data.trainerId,
        introVideoUrl: data.introVideoUrl || null,
        posterUrl,
      },
    });

    revalidatePath("/dashboard/admin/courses");
    revalidatePath("/courses");
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : "حدث خطأ غير متوقع" };
  }
}

export async function updateCourse(courseId: string, formData: FormData): Promise<ActionResult> {
  try {
    await requireCourseManager(courseId);
    const parsed = courseSchema
      .omit({ trainerId: true })
      .extend({ trainerId: z.string().trim().optional() })
      .safeParse({
        title: formData.get("title"),
        titleEn: formData.get("titleEn"),
        subtitle: formData.get("subtitle"),
        subtitleEn: formData.get("subtitleEn"),
        description: formData.get("description"),
        descriptionEn: formData.get("descriptionEn"),
        price: formData.get("price") || 0,
        level: formData.get("level") || "BEGINNER",
        categoryId: formData.get("categoryId"),
        trainerId: formData.get("trainerId") ?? undefined,
        introVideoUrl: formData.get("introVideoUrl"),
      });
    if (!parsed.success) {
      return { ok: false, error: parsed.error.issues[0]?.message ?? "بيانات غير صحيحة" };
    }
    const data = parsed.data;
    const user = await requireUser();

    let posterUrl: string | undefined;
    const poster = formData.get("poster");
    if (poster instanceof File && poster.size > 0) {
      assertValidPoster(poster);
      posterUrl = await savePublicImage(poster, "posters");
    }

    await prisma.course.update({
      where: { id: courseId },
      data: {
        title: data.title,
        titleEn: data.titleEn || null,
        subtitle: data.subtitle || null,
        subtitleEn: data.subtitleEn || null,
        description: data.description || null,
        descriptionEn: data.descriptionEn || null,
        price: data.price,
        level: data.level,
        categoryId: data.categoryId || null,
        introVideoUrl: data.introVideoUrl || null,
        ...(posterUrl ? { posterUrl } : {}),
        ...(user.role === "ADMIN" && data.trainerId ? { trainerId: data.trainerId } : {}),
        ...(user.role === "ADMIN" ? { totalHours: parseOptionalHours(formData) } : {}),
      },
    });

    revalidatePath("/dashboard");
    revalidatePath("/courses");
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : "حدث خطأ غير متوقع" };
  }
}

export async function setCoursePublished(courseId: string, published: boolean): Promise<ActionResult> {
  try {
    await requireCourseManager(courseId);
    await prisma.course.update({ where: { id: courseId }, data: { published } });
    revalidatePath("/dashboard");
    revalidatePath("/courses");
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : "حدث خطأ غير متوقع" };
  }
}

export async function deleteCourse(courseId: string): Promise<ActionResult> {
  try {
    await requireRole(["ADMIN"]);
    await prisma.course.delete({ where: { id: courseId } });
    revalidatePath("/dashboard/admin/courses");
    revalidatePath("/courses");
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : "حدث خطأ غير متوقع" };
  }
}

export async function createSection(courseId: string, formData: FormData): Promise<ActionResult> {
  try {
    await requireCourseManager(courseId);
    const title = String(formData.get("title") ?? "").trim();
    if (title.length < 2) return { ok: false, error: "عنوان القسم قصير جدًا" };

    const count = await prisma.section.count({ where: { courseId } });
    await prisma.section.create({ data: { courseId, title, order: count + 1 } });
    revalidatePath("/dashboard");
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : "حدث خطأ غير متوقع" };
  }
}

export async function updateSectionTitle(sectionId: string, formData: FormData): Promise<ActionResult> {
  try {
    const section = await prisma.section.findUnique({ where: { id: sectionId }, select: { courseId: true } });
    if (!section) return { ok: false, error: "القسم غير موجود" };
    await requireCourseManager(section.courseId);

    const title = String(formData.get("title") ?? "").trim();
    if (title.length < 2) return { ok: false, error: "عنوان القسم قصير جدًا" };
    const titleEn = String(formData.get("titleEn") ?? "").trim();

    await prisma.section.update({ where: { id: sectionId }, data: { title, titleEn: titleEn || null } });
    revalidatePath("/dashboard");
    revalidatePath("/courses");
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : "حدث خطأ غير متوقع" };
  }
}

export async function deleteSection(sectionId: string): Promise<ActionResult> {
  try {
    const section = await prisma.section.findUnique({ where: { id: sectionId }, select: { courseId: true } });
    if (!section) return { ok: false, error: "القسم غير موجود" };
    await requireCourseManager(section.courseId);
    await prisma.section.delete({ where: { id: sectionId } });
    revalidatePath("/dashboard");
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : "حدث خطأ غير متوقع" };
  }
}

export async function updateSectionCover(sectionId: string, formData: FormData): Promise<ActionResult> {
  try {
    await requireRole(["ADMIN"]);
    const section = await prisma.section.findUnique({ where: { id: sectionId }, select: { id: true } });
    if (!section) return { ok: false, error: "القسم غير موجود" };

    const cover = formData.get("cover");
    if (!(cover instanceof File) || cover.size === 0) {
      return { ok: false, error: "يرجى اختيار صورة الغلاف" };
    }
    assertValidPoster(cover);
    const coverImageUrl = await savePublicImage(cover, "section-covers");

    await prisma.section.update({ where: { id: sectionId }, data: { coverImageUrl } });
    revalidatePath("/dashboard");
    revalidatePath("/courses");
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : "حدث خطأ غير متوقع" };
  }
}

export async function reorderSections(courseId: string, orderedIds: string[]): Promise<ActionResult> {
  try {
    await requireCourseManager(courseId);
    await prisma.$transaction(
      orderedIds.map((id, index) =>
        prisma.section.update({ where: { id }, data: { order: index + 1 } })
      )
    );
    revalidatePath("/dashboard");
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : "حدث خطأ غير متوقع" };
  }
}

export async function createLesson(sectionId: string, formData: FormData): Promise<ActionResult> {
  try {
    const section = await prisma.section.findUnique({ where: { id: sectionId }, select: { courseId: true } });
    if (!section) return { ok: false, error: "القسم غير موجود" };
    await requireCourseManager(section.courseId);

    const title = String(formData.get("title") ?? "").trim();
    if (title.length < 2) return { ok: false, error: "عنوان الدرس قصير جدًا" };

    const count = await prisma.lesson.count({ where: { sectionId } });
    await prisma.lesson.create({ data: { sectionId, title, order: count + 1 } });
    revalidatePath("/dashboard");
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : "حدث خطأ غير متوقع" };
  }
}

export async function updateLessonTitle(lessonId: string, formData: FormData): Promise<ActionResult> {
  try {
    const lesson = await prisma.lesson.findUnique({
      where: { id: lessonId },
      select: { section: { select: { courseId: true } } },
    });
    if (!lesson) return { ok: false, error: "الدرس غير موجود" };
    await requireCourseManager(lesson.section.courseId);

    const title = String(formData.get("title") ?? "").trim();
    if (title.length < 2) return { ok: false, error: "عنوان الدرس قصير جدًا" };
    const titleEn = String(formData.get("titleEn") ?? "").trim();

    await prisma.lesson.update({ where: { id: lessonId }, data: { title, titleEn: titleEn || null } });
    revalidatePath("/dashboard");
    revalidatePath("/courses");
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : "حدث خطأ غير متوقع" };
  }
}

export async function deleteLesson(lessonId: string): Promise<ActionResult> {
  try {
    const lesson = await prisma.lesson.findUnique({
      where: { id: lessonId },
      select: { section: { select: { courseId: true } } },
    });
    if (!lesson) return { ok: false, error: "الدرس غير موجود" };
    await requireCourseManager(lesson.section.courseId);
    await prisma.lesson.delete({ where: { id: lessonId } });
    revalidatePath("/dashboard");
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : "حدث خطأ غير متوقع" };
  }
}

export async function updateLessonCover(lessonId: string, formData: FormData): Promise<ActionResult> {
  try {
    await requireRole(["ADMIN"]);
    const lesson = await prisma.lesson.findUnique({ where: { id: lessonId }, select: { id: true } });
    if (!lesson) return { ok: false, error: "الدرس غير موجود" };

    const cover = formData.get("cover");
    if (!(cover instanceof File) || cover.size === 0) {
      return { ok: false, error: "يرجى اختيار صورة الغلاف" };
    }
    assertValidPoster(cover);
    const coverImageUrl = await savePublicImage(cover, "lesson-covers");

    await prisma.lesson.update({ where: { id: lessonId }, data: { coverImageUrl } });
    revalidatePath("/dashboard");
    revalidatePath("/courses");
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : "حدث خطأ غير متوقع" };
  }
}

export async function reorderLessons(sectionId: string, orderedIds: string[]): Promise<ActionResult> {
  try {
    const section = await prisma.section.findUnique({ where: { id: sectionId }, select: { courseId: true } });
    if (!section) return { ok: false, error: "القسم غير موجود" };
    await requireCourseManager(section.courseId);
    await prisma.$transaction(
      orderedIds.map((id, index) =>
        prisma.lesson.update({ where: { id }, data: { order: index + 1 } })
      )
    );
    revalidatePath("/dashboard");
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : "حدث خطأ غير متوقع" };
  }
}
